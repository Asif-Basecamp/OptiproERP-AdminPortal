export class UserGroupModel {
    UserGroupId:string;  
    UserGroupDesc:string; 
    IsAdminEnabled:boolean=false;
    isGrpIdEditable:boolean; 
    mapped_user:string;
    mapped_Password:string;
    PreviousGrpId:string;
    
}
