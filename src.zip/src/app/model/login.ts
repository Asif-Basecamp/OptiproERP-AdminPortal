export class Login {
    UserName:string;  
    Password:string;  
}
