export class Role {
    RoleId:string;  
    RoleDesc:string; 
    Product:string;
    PriviousRoleId:string;
}
