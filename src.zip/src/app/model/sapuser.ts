export class SapUser {
    UserGroupId:string;  
    UserGroupDesc:string; 
    IsAdminEnabled:boolean;
    isGrpIdEditable:boolean; 
    mapped_user:string;
    mapped_Password:string;
    PreviousGrpId:string;
    
}